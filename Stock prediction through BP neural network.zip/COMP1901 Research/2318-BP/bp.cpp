#include <bits/stdc++.h>
using namespace std;

struct Matrix{
    int n, m;
    double mt[15][15];
    Matrix(int N, int M, int ifrand){
        n = N, m = M;
        for(int i = 1; i <= N; i++)
            for(int j = 1; j <= M; j++){
				mt[i][j] = ifrand * ((rand()%100+1) / 100.0);
            }
    }
};

Matrix operator * (const Matrix &a, const Matrix &b){
    Matrix c(a.n, b.m, 0);
    for(int i = 1; i <= c.n; i++){
        for(int j = 1; j <= c.m; j++){
            for(int k = 1; k <= a.m; k++){
                c.mt[i][j] += a.mt[i][k] * b.mt[k][j];
            }
        }
    }
    return c;
}
Matrix operator * (const double &a, const Matrix &b){
    Matrix c(b.n, b.m, 0);
    for(int i = 1; i <= c.n; i++){
        for(int j = 1; j <= c.m; j++){
            c.mt[i][j] = a * b.mt[i][j];
        }
    }
    return c;
}

const double e = 2.718281828459;
const double r = 0.1;

inline double sigmod(double x){
    return (1.0 / (1.0 + pow(e, -x)));
}
inline double dsigmod(double x){
    return sigmod(x) * (1.0 - sigmod(x));
}

Matrix inp_in(5, 1, 0);
Matrix inp_out(5, 1, 0);
Matrix oup_in(1, 1, 0);
Matrix oup_out(5, 1, 0);
Matrix hid1_in(10, 1, 0);
Matrix hid1_out(10, 1, 0);
Matrix hid2_in(10, 1, 0);
Matrix hid2_out(10, 1, 0);
Matrix w1(10, 5, 1);
Matrix w2(10, 10, 1);
Matrix w3(1, 10, 1);
Matrix b1(10, 1, 1);
Matrix b2(10, 1, 1);
Matrix b3(5, 1, 1);

double E, sE;

void fw(){
	//cout<<w1.n<<"  "<<w1.m<<"  "<<inp_out.n<<"  "<<inp_out.m<<endl;
    hid1_in = w1 * inp_out;
    //cout<<" Mul !"<<endl;
    for(int i = 1; i <= hid1_in.n; i++)
        hid1_out.mt[i][1] = sigmod(hid1_in.mt[i][1] + b1.mt[i][1]);
    hid2_in = w2 * hid1_out;
    for(int i = 1; i <= hid1_in.n; i++)
        hid2_out.mt[i][1] = sigmod(hid2_in.mt[i][1] + b2.mt[i][1]);
    oup_in = w3 * hid2_out;
    oup_out.mt[1][1]  = sigmod(oup_in.mt[1][1]);
}

void bp(double y) {
    E = (y - oup_out.mt[1][1]) * (y - oup_out.mt[1][1]);
	sE += E;
	
    double dEdout = 2 * oup_out.mt[1][1] - 2 * y;

    Matrix dEdhid2(hid2_out.n,hid2_out.m,0);
    for(int i = 1; i <= oup_in.n; i++){
        for(int j = 1; j <= hid2_out.n; j++){
            dEdhid2.mt[j][1] += dEdout * dsigmod(oup_in.mt[i][1]) * w3.mt[i][j];
            w3.mt[i][j] -= r * dEdout * dsigmod(oup_in.mt[i][1]) * hid2_out.mt[j][1];
            //cout<<"     "<<dsigmod(oup_in.mt[i][1])<<"  "<<oup_in.mt[i][1]<<" "<<hid2_out.mt[j][1]<<endl;
        }
        b3.mt[i][1] -= r * dEdout * dsigmod(oup_in.mt[i][1]);
    }

    Matrix dEdhid1(hid1_out.n,hid1_out.m,0);
    for(int i = 1; i <= hid2_in.n; i++){
        for(int j = 1; j <= hid1_out.n; j++){
            dEdhid1.mt[j][1] += dEdhid2.mt[i][1] * dsigmod(hid2_in.mt[i][1]) * w2.mt[i][j];
            w2.mt[i][j] -= r * dEdhid2.mt[i][1] * dsigmod(hid2_in.mt[i][1]) * hid1_out.mt[j][1];
        }
        b2.mt[i][1] -= r * dEdhid2.mt[i][1] * dsigmod(hid2_in.mt[i][1]);
    }

    Matrix dEdinp(inp_out.n, inp_out.m, 0);
    for(int i = 1; i <= hid1_in.n; i++){
        for(int j = 1; j <= inp_out.n; j++){
            dEdinp.mt[j][1] += dEdhid1.mt[i][1] * dsigmod(hid1_in.mt[i][1]) * w1.mt[i][j];
            w1.mt[i][j] -= r * dEdhid1.mt[i][1] * dsigmod(hid1_in.mt[i][1]) * inp_out.mt[j][1];
        }
        w1.mt[i][1] -= r * dEdhid1.mt[i][1] * dsigmod(hid1_in.mt[i][1]);
    }
}

double price[1000];

void print(Matrix X){
	for(int i = 1; i <= X.n; i++){
		for(int j = 1; j <= X.m; j++){
			printf("%.4f ", X.mt[i][j]);
		}
		printf("\n");
	}
}

int main(){
	srand(time(0));
    freopen("2318.txt","r",stdin);
    freopen("Train.out","w",stdout);
    int n;
    scanf("%d", &n);
    for(int i = 1; i <= n; i++){
    	scanf("%lf",&price[i]);
    	price[i] = price[i] / 100.0;
	}
	cout<<"Data Loaded"<<endl;
	print(Matrix(3,3,1));
	//cout<<sigmod(5)<<"  "<<sigmod(4)<<"  "<<sigmod(3)<<"  "<<sigmod(2)<<"  "<<sigmod(1)<<"  "<<sigmod(0)<<endl;
	//cout<<dsigmod(5)<<"  "<<dsigmod(4)<<"  "<<dsigmod(3)<<"  "<<dsigmod(2)<<"  "<<dsigmod(1)<<"  "<<dsigmod(0)<<endl;

	//return 0;
	int batch = 0;
	while(1){
		int sp = 0;
		batch = (batch + 1) % 5;
		for(int i = 5 + batch; i < n; i+=5){
			sp++;
			if(sp > 100) break;
			for(int j = i - 4; j <= i; j++){
				inp_out.mt[j-i+5][1] = price[j];
			}
			//cout<<" FW "<<endl;
			//cout<<w1.n<<"  "<<w1.m<<endl;
			//cout<<inp_out.n<<"  "<<inp_out.m<<endl;
			fw();
			//cout<<" BP "<<endl;
			bp(price[i+1]);
			//printf("Error: %.4f\n", E*10000);
		}
		printf("%.4f\n", sE*10000);
		if(sE * 10000 < 600){
			cout<<"----------- w1 -----------"<<endl;
			print(w1);
			cout<<"----------- w2 -----------"<<endl;
			print(w2);
			cout<<"----------- w3 -----------"<<endl;
			print(w3);
			cout<<"----------- b1 -----------"<<endl;
			print(b1);
			cout<<"----------- b2 -----------"<<endl;
			print(b2);
			cout<<"----------- b3 -----------"<<endl;
			print(b3);
			return 0;
		}
		
		sE = 0;
		
		//print(w1);
		//print(w2);
		//print(w3);
		
		//sleep();
	}
    return 0;
}

#include <bits/stdc++.h>
using namespace std;

const double eps = 1e-6;

int n;
double price[1000];
double sum[1000];
bool below[11];
double money[11];

int main(){
	freopen("2318.txt","r",stdin);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%lf", &price[i]);
		sum[i] = sum[i-1] + price[i];
	}
	for(int i = 1; i <= 10; i++) money[i] = 100.0;
	for(int i = 10; i <= n; i++){
		for(int j = 1; j <= 10; j++){
			double average = (sum[i] - sum[i - j]) / j;
			if(average >= (price[i] - eps)){
				if(below[j] == 1){
					money[j] *= price[i];
					money[j] -= money[j] * 0.0013;
				}
				below[j] = 0;
			}
			else{
				if(below[j] == 0){
					money[j] /= price[i];
				}
				below[j] = 1;
			}
		}
	}
	for(int i = 1; i <= 10; i++){
		if(below[i] == 1)
			money[i] *= price[n];
		printf("%.4f ", money[i]);
	}
	return 0;
}
Run the main.cpp.
If you want to clear the block-chain data, please delete the data.txt, and create a new data.txt in there. And input a 0 on the beginning of the data.txt.